import React from 'react';
import './App.css';

function App() {
  return (
    <div className="container">
      <header>
        <h1>Job Board</h1>
      </header>
      <div className="job-listing">
        <div className="job">
          <h2>Web Developer</h2>
          <p>ABC Technologies</p>
          <p>New York, NY</p>
          <p>We are looking for a skilled web developer to join our team. Must have experience with HTML, CSS, and JavaScript.</p>
          <a className="apply-button" href="#">Apply Now</a>
        </div>
        <div className="job">
          <h2>Graphic Designer</h2>
          <p>XYZ Creative Agency</p>
          <p>Los Angeles, CA</p>
          <p>We are seeking a creative graphic designer with expertise in Adobe Photoshop and Illustrator.</p>
          <a className="apply-button" href="#">Apply Now</a>
        </div>
        <div className="job">
          <h2>Marketing Manager</h2>
          <p>123 Marketing Inc.</p>
          <p>Chicago, IL</p>
          <p>We are hiring a marketing manager with proven experience in developing and executing marketing strategies.</p>
          <a className="apply-button" href="#">Apply Now</a>
        </div>
      </div>
    </div>
  );
}

export default jobboard;
