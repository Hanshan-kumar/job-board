import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  
  

  return (
    <>
     <div className="banner">
            <div className="navbar">
                <img src="logo.png" class="logo" alt="Logo"  />
                <ul> </ul>
            </div>

            <div className="content">
                <h1>MAKE YOUR BRIGHT FUTURE HERE!</h1>
                <p>The expert in anything was once a beginner.<br />Are you looking for</p>
                <div>
                    <button type="button"><span></span>Job seeker</button>
                    <button type="button"><span></span>Employer</button>
                </div>
            </div>
        </div>
    </>
  )
}

export default App
